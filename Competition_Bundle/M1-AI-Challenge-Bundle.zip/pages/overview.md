# Overview of the Challenge
*** 
Here you can describe in detail what your challenge is and give all the details about how to participate and other details. Below is a template you can use.

***


## Introduction
***
...

## Competition Tasks
***
...

## Competition Phases
***
...



## How to join this competition?
***
- Login or Create Account on [<ins>Codabench</ins>](https://www.codabench.org/) 
- Go to the `Starting Kit` tab
- Download the `Dummy Sample Submission`
- Go to the `My Submissions` tab
- Register in the Competition
- Submit the downloaded file


## Submissions
***
This competition allows only result submissions. Participants can submit a result submission as instructed in the `Starting Kit` tab.


## Timeline
***
...


## Credits
***
...



## Contact
***
...