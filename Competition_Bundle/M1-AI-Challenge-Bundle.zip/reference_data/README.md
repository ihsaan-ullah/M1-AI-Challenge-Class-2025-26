# Reference Data
Reference Data consists of Test labels. These are separated from Input Data to make sure only scoring program can access them. These should not be made available to ingestion program.